/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import java.io.IOException;

/**
 *
 * @author Owner
 */
public class TicTacToe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        boardForm board = new boardForm();
        board.setVisible(true);
    }
}
